#pragma once
#include <iostream>
using namespace std;

class Activity {
private:
	string Status;
	string Detail;
public:
	Activity(string S = "", string D = "") {
		Status = S;
		Detail = D;
	}
	string GetStatus() {
		return Status;
	}
	string GetDetail() {
		return Detail;
	}
};