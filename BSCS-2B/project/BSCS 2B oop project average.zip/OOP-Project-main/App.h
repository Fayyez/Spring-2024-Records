#include <iostream>
#include <vector>
#include <fstream>
#include <cstring>
#include "Entityclass.h"
#include <string>
using namespace std;
void tolower(string& s1) {
	for (int i = 0; i < s1.length(); i++) {
		s1[i] = tolower(s1[i]);
	}
}

namespace l233010 {
	
	class PookieDatingSimulator {
		vector <Entity*> UserArray = {};
		vector<Post*> PostArray = {};
		vector <Memory*> Memories = {};
	public:

		void InitializeUsersArray(vector<Entity*>& Users) {
			ifstream UserFile;
			UserFile.open("Users.txt");
			int NumberOfUsers;
			string ID;
			string FName;
			string LName;
			string FullName;
			string temp;
			UserFile >> NumberOfUsers;
			vector <string> Friends;
			vector <string> Pages;
			while (!UserFile.eof()) {
				UserFile >> ID;
				UserFile >> FName;
				UserFile >> LName;
				FullName = FName + " " + LName;
				UserFile >> temp;
				Friends = {};
				Pages = {};
				while (temp != "-1") {
					Friends.push_back(temp);
					UserFile >> temp;
				}
				UserFile >> temp;
				while (temp != "-1") {
					Pages.push_back(temp);
					UserFile >> temp;
				}
				User* U1 = new User(ID, FullName, Friends, Pages);
				Users.push_back(U1);
			}
		}

		void InitializePagesInArray(vector <Entity*>& PostArray) {
			ifstream PageFile;
			PageFile.open("Pages.txt");
			int NumberOfPages;
			PageFile >> NumberOfPages;
			PageFile.ignore();
			for (int i = 0; i < NumberOfPages; i++) {
				string PageID;
				string Name;
				PageFile >> PageID;
				PageFile.ignore();
				getline(PageFile, Name);
				Page* P1 = new Page(PageID, Name);
				PostArray.push_back(P1);
			}
		}

		Activity* SetActivity(int Type, string D) {
			if (Type == 1) {
				Activity* A = new Activity("Feeling", D);
				return A;
			}
			else if (Type == 2) {
				Activity* A = new Activity("Celebrating", D);
				return A;
			}
			else if (Type == 3) {
				Activity* A = new Activity("Thinking-about", D);
				return A;
			}
			else if (Type == 4) {
				Activity* A = new Activity("Making", D);
				return A;
			}
			else {
				Activity* A = new Activity("Wrong", "Input");
				return A;
			}
		}

		void InitializeCommentsInPosts(vector<Post*>& Posts, vector <Entity*>& Users) {
			ifstream CommentFile;
			CommentFile.open("Comments.txt");
			int NumberOfComments;
			CommentFile >> NumberOfComments;
			CommentFile.ignore();
			for (int i = 0; i < NumberOfComments; i++) {
				string ID;
				string PostedOn;
				string PostedBy;
				string Text;
				CommentFile >> ID;
				CommentFile.ignore();
				CommentFile >> PostedOn;
				CommentFile.ignore();
				CommentFile >> PostedBy;
				CommentFile.ignore();
				getline(CommentFile, Text);
				Comment* C1 = new Comment(ID, PostedOn, PostedBy, Text);
				for (Post* P : Posts) {
					if (PostedOn == P->GetID()) {
						P->AddComment(C1);
					}
				}
				for (Entity* E : Users) {
					if (PostedBy == E->GetID()) {
						E->AddComment(C1);
					}
				}
			}
		}


		void InitializePostArray(vector <Post*>& Posts) {
			ifstream PostFile;
			PostFile.open("Posts.txt", ios::in);
			int NumberOfPosts;
			PostFile >> NumberOfPosts;

			vector <Comment*> Comments = {};
			int i = 0;
			while (i < NumberOfPosts) {
				int HasActivity;
				string PostID;
				int day, month, year;
				string description;
				string postedby;
				vector <string> likedby;
				int activitytype = 0;
				string owner;
				string activitydes = "";
				PostFile >> HasActivity;
				PostFile >> PostID;
				PostFile >> day;
				PostFile >> month;
				PostFile >> year;
				PostFile.ignore();
				getline(PostFile, description);
				if (HasActivity == 2) {
					PostFile >> activitytype;
					getline(PostFile, activitydes);

					Activity* A = SetActivity(activitytype, activitydes);
					PostFile >> owner;
					string Likers;
					PostFile >> Likers;
					while (Likers != "-1") {
						likedby.push_back(Likers);
						PostFile >> Likers;
					}
					Post* P1 = new Post(PostID, day, month, year, description, A, owner, likedby);
					Posts.push_back(P1);
				}
				else {
					PostFile >> owner;
					string Likers;
					PostFile >> Likers;
					while (Likers != "-1") {
						likedby.push_back(Likers);
						PostFile >> Likers;
					}
					Post* P1 = new Post(PostID, day, month, year, description, nullptr, owner, likedby);
					Posts.push_back(P1);
				}
				i++;
			}
		}


		Entity* SetDefaultUser(vector <Entity*>& Users) {
			cout << "Please enter UserID." << endl;
			string input;
			bool successfullogin = 0;
			while (successfullogin == 0) {
				cin >> input;
				tolower(input);
				for (Entity* E : Users) {
					if (E->GetID() == input) {
						cout << "User " << E->GetName() << " has been made the default user." << endl;
						successfullogin = 1;
						return E;
					}
				}
				cout << "User not found in database. Please reenter the UID." << endl;
			}
			return 0;
		}

		void ViewFriendList(Entity* User, vector <Entity*>& Users) {
			vector <string> FriendList = User->GetFriendList();
			cout << User->GetName() << " Friend List : " << endl << endl;;
			for (string s : FriendList) {
				for (Entity* U : Users) {
					if (U->GetID() == s && U->GetID() != User->GetID()) {
						cout << U->GetID() << " -> " << U->GetName() << endl;
					}
				}
			}
			cout << "--------------------------------------------" << endl;
		}

		void ViewLikedPages(Entity* User, vector <Entity*> Users) {
			vector <string> LikedPages = User->GetLikedPages();
			cout << User->GetName() << " Liked Pages : " << endl << endl;
			for (string s : LikedPages) {
				for (Entity* U : Users) {
					if (U->GetID() == s && U->GetID() != User->GetID()) {
						cout << U->GetID() << " -> " << U->GetName() << endl;
					}
				}
			}
			cout << "--------------------------------------------" << endl;
		}

		void DisplayHomePage(Time* CurrentTime, Entity* CurrentUser) {
			cout << CurrentUser->GetName() << " --> HomePage." << endl;


		}


		void ViewProfile(Entity* CurrentUser, vector <Post*>& Posts, vector <Entity*>& Users) {


			for (Post* P : Posts) {
				if (CurrentUser->GetID() == P->GetOwner()) {
					if (P->GetActivity() != nullptr) {
						cout << CurrentUser->GetName() << " is " << P->GetActivity()->GetStatus() << " " << P->GetActivity()->GetDetail() << endl;
					}
					else {
						cout << CurrentUser->GetName() << " posted :" << endl;
					}
					cout << "\t" << "\"" << P->GetDescription() << "\"" << " ... ";
					P->GetTime().PrintTime();
					vector <Comment*> Comments = {};
					Comments = P->GetComments();
					for (Entity* E : Users) {
						for (Comment* C : Comments) {
							if (E->GetID() == C->GetPostedBy()) {
								cout << "\t\t" << E->GetName() << " wrote " << " \"" << C->GetText() << "\"" << endl;
							}
						}
					}
					cout << endl;

				}
			}
			cout << "-------------------------------------------------------------" << endl;
		}

		void ViewHomefOfUser(Entity* CurrentUser, vector <Post*>& Posts, vector <Entity*>& Users, Time* CurrentTime) {
			vector <string> Friends = CurrentUser->GetFriendList();
			vector <string> Pages = CurrentUser->GetLikedPages();
			for (string A : Pages) {
				Friends.push_back(A);
			}
			for (Post* P : PostArray) {
				if (CurrentTime->GetDate() - P->GetTime().GetDate() <= 1 && CurrentTime->GetDate() - P->GetTime().GetDate() >= 0 && CurrentTime->GetMonth() == P->GetTime().GetMonth() && CurrentTime->GetYear() == P->GetTime().GetYear()) {
					for (string S : Friends) {
						if (P->GetOwner() == S) {
							for (Entity* E : UserArray) {
								if (P->GetActivity() != nullptr) {
									if (E->GetID() == P->GetOwner()) {
										cout << E->GetName() << " is " << P->GetActivity()->GetStatus() << " " << P->GetActivity()->GetDetail() << endl;
										cout << "\t" << "\"" << P->GetDescription() << "\"" << " ... ";
										P->GetTime().PrintTime();
										vector <Comment*> Comments = {};
										Comments = P->GetComments();
										for (Entity* U : Users) {
											for (Comment* C : Comments) {
												if (U->GetID() == C->GetPostedBy()) {
													cout << "\t\t" << U->GetName() << " wrote " << " \"" << C->GetText() << "\"" << endl;
												}
											}
										}
										cout << endl;
									}
								}
								else {
									if (E->GetID() == P->GetOwner()) {
										cout << CurrentUser->GetName() << " posted :" << endl;
										cout << "\t" << "\"" << P->GetDescription() << "\"" << " ... ";
										P->GetTime().PrintTime();
										vector <Comment*> Comments = {};
										Comments = P->GetComments();
										for (Entity* U : Users) {
											for (Comment* C : Comments) {
												if (U->GetID() == C->GetPostedBy()) {
													cout << "\t\t" << U->GetName() << " wrote " << " \"" << C->GetText() << "\"" << endl;
												}
											}
										}
										cout << endl;
									}
								}

							}
						}
					}
				}
			}
		}

		void ViewLikedList(string ID, vector<Post*>& Posts, vector <Entity*>& Users) {
			for (Post* P : Posts) {
				if (P->GetID() == ID) {
					cout << "Post Liked By :" << endl;
					vector <string> LikedBy = {};
					LikedBy = P->GetLikedBy();
					for (Entity* U : Users) {
						for (string S : LikedBy) {
							if (U->GetID() == S) {
								cout << U->GetID() << "-->" << U->GetName() << endl;
							}
						}
					}
				}
			}
			cout << "-------------------------------------------------------------------" << endl;
		}


		void LikePost(Entity*& CurrentUser, string ID, vector<Post*>& Posts, vector <Entity*>& Users) {
			for (Post* P : Posts) {
				if (P->GetID() == ID) {
					vector <string> LikedBy = {};
					LikedBy = P->GetLikedBy();
					string uid = CurrentUser->GetID();
					bool flag = 0;
					for (string S : LikedBy) {
						if (S == uid) {
							flag = 1;
						}
					}
					if (flag == 0 && LikedBy.size() < 10) {
						LikedBy.push_back(uid);
					}
					else if (flag == 1) {
						cout << "Post already Liked." << endl;
					}
					else {
						cout << "Liked limit reached." << endl;
					}
					P->SetLikers(LikedBy);
					cout << "Post Liked." << endl;
				}
			}

		}

		void PostComment(Entity* ActiveUser, string ID, string text, vector <Post*>& Posts) {
			for (Post* P : Posts) {
				if (ID == P->GetID()) {
					Comment* C = new Comment("", P->GetID(), ActiveUser->GetID(), text);
					P->AddComment(C);
				}
			}
		}

		void ViewPost(string ID, vector<Post*>& Posts, vector <Entity*>& Users) {
			for (Post* P : Posts) {
				if (ID == P->GetID()) {

					if (P->GetActivity() != nullptr) {
						for (Entity* CurrentUser : Users) {
							if (CurrentUser->GetID() == P->GetOwner()) {
								cout << CurrentUser->GetName() << " is " << P->GetActivity()->GetStatus() << " " << P->GetActivity()->GetDetail() << endl;
							}
						}
					}
					else {
						for (Entity* CurrentUser : Users) {
							if (CurrentUser->GetID() == P->GetOwner()) {
								cout << CurrentUser->GetName() << " posted :" << endl;
							}
						}
					}
					cout << "\t" << "\"" << P->GetDescription() << "\"" << " ... ";
					P->GetTime().PrintTime();
					vector <Comment*> Comments = {};
					Comments = P->GetComments();
					for (Entity* E : Users) {
						for (Comment* C : Comments) {
							if (E->GetID() == C->GetPostedBy()) {
								cout << "\t\t" << E->GetName() << " wrote " << " \"" << C->GetText() << "\"" << endl;
							}
						}
					}
					cout << endl;
				}
			}
		}

		void ViewPage(string ID, vector <Post*>& Posts, vector <Entity*>& Users) {
			for (Entity* E : Users) {
				if (E->GetID() == ID) {
					ViewProfile(E, Posts, Users);
				}
			}
			cout << "-------------------------------------------------------------" << endl;
		}

		Time* SetCurrentTime() {
			cout << "Please enter date, month and year one by one. " << endl;
			int month, date, year;
			cin >> date;
			cin >> month;
			cin >> year;
			Time* T = new Time(date, month, year);
			T->PrintTime();
			cout << " Has been set the current date." << endl;
			return T;
		}

		void ShareMemory(vector <Memory*>& Memos, vector <Post*>& Posts, string Text, string PostID, Entity* CurrentUser) {
			for (Post* P : Posts) {
				if (P->GetID() == PostID) {
					Memory* M1 = new Memory(CurrentUser->GetID(), P, Text);
					Memos.push_back(M1);
				}
			}
		}

		void ViewMemories(vector<Memory*> Memos, Entity* CurrentUser, Time* CurrentDate, vector<Entity*> Users) {
			cout << "Memories :" << endl;
			vector<Post*> PostsFound = {};
			vector<string> TestFound = {};
			for (Memory* M : Memos) {
				if (M->GetID() == CurrentUser->GetID()) {
					int y = CurrentDate->GetYear();
					int x = M->GetMomories()->GetTime().GetYear();
					int Lapse = y - x;
					cout << CurrentUser->GetName() << " Shared a Memory... (" << Lapse << ")" << endl;
					cout << M->GetTexts() << endl;
					if (M->GetMomories()->GetActivity() != nullptr) {
						cout << CurrentUser->GetName() << " is " << M->GetMomories()->GetActivity()->GetStatus() << " " << M->GetMomories()->GetActivity()->GetDetail() << endl;
					}
					else {
						cout << CurrentUser->GetName() << " posted :" << endl;
					}
					cout << "\t" << "\"" << M->GetMomories()->GetDescription() << "\"" << " ... ";
					M->GetMomories()->GetTime().PrintTime();
					vector <Comment*> Comments = {};
					Comments = M->GetMomories()->GetComments();
					for (Entity* E : Users) {
						for (Comment* C : Comments) {
							if (E->GetID() == C->GetPostedBy()) {
								cout << "\t\t" << E->GetName() << " wrote " << " \"" << C->GetText() << "\"" << endl;
							}
						}
					}
					cout << endl;
				}
			}
		}


		void ViewHome(vector<Memory*>& Memos, Entity* CurrentUser, Time* CurrentTime, vector<Entity*>& Users, vector <Post*>& Posts) {
			cout << CurrentUser->GetName() << " : Viewing HomePage ==>" << endl << endl;
			ViewMemories(Memos, CurrentUser, CurrentTime, Users);
			cout << "-----------------------------------------------------------------------" << endl;
			ViewProfile(CurrentUser, Posts, Users);
			cout << "-----------------------------------------------------------------------" << endl;
		}


		string getcommands(vector <Entity*>& UserArray, vector<Post*>& PostArray, vector <Memory*>& Memories) {
			Time* CurrentTime;
			CurrentTime = SetCurrentTime();
			string Command = "";
			cout << "Please enter the commands. Enter \"!help\" to see list of Commands." << endl;
			getline(cin, Command);
			tolower(Command);
			Entity* CurrentUser = nullptr;
			bool validcommand = 1;
			while (Command != "!exit") {
				validcommand = 0;
				if (Command == "!help") {
					cout << "\t!setuser --> Set an active user (Login)" << endl;
					cout << "\t!like -> Like a post." << endl;
					cout << "\t!viewlikes -> View Users who liked a post." << endl;
					cout << "\t!viewfriends -> View Friend List of the user." << endl;
					cout << "\t!viewlikedpages -> View Liked Pages of the user." << endl;
					cout << "\t!viewhome -> View Home Page of the user." << endl;
					cout << "\t!viewprofile -> View a Users Profile." << endl;
					cout << "\t!postcomment -> Add a comment on a Post." << endl;
					cout << "\t!viewpost -> View a post along with its comments." << endl;
					cout << "\t!seememories -> View all memories shared." << endl;
					cout << "\t!sharememory -> Share a post as a memory." << endl;
					cout << "\t!viewtimeline -> View a users timeline." << endl;
					cout << "\t!viewpage -> View all posts of a page." << endl;
					cout << "\t\t!exit --> Exit the app." << endl;
					cout << "<---------------------------------------------------------------->" << endl;
					!validcommand;

				}
				else if (Command == "!setuser") {
					CurrentUser = SetDefaultUser(UserArray);
					!validcommand;
				}
				else if (Command == "!like" && CurrentUser != nullptr) {
					cout << "Please enter the post you want to like." << endl;
					string PID;
					cin >> PID;
					LikePost(CurrentUser, PID, PostArray, UserArray);
					!validcommand;
				}
				else if (Command == "!viewlikes" && CurrentUser != nullptr) {
					cout << "Please enter the post you want to see likes on." << endl;
					string PID;
					cin >> PID;
					ViewLikedList(PID, PostArray, UserArray);
					!validcommand;
				}
				else if (Command == "!viewfriends" && CurrentUser != nullptr) {
					ViewFriendList(CurrentUser, UserArray);
					!validcommand;
				}
				else if (Command == "!viewlikedpages" && CurrentUser != nullptr) {
					ViewLikedPages(CurrentUser, UserArray);
					!validcommand;
				}
				else if (Command == "!viewprofile" && CurrentUser != nullptr) {
					if (CurrentUser->GetID()[0] == 'u') {
						cout << CurrentUser->GetName() << " : Viewing Profile" << endl;
					}
					else {
						cout << CurrentUser->GetName() << " : Viewing Page" << endl;
					}
					ViewProfile(CurrentUser, PostArray, UserArray);
					!validcommand;
				}
				else if (Command == "!viewpost" && CurrentUser != nullptr) {
					cout << "Please enter the PostID you want to view." << endl;
					string id;
					cin >> id;
					ViewPost(id, PostArray, UserArray);
					!validcommand;
				}
				else if (Command == "!postcomment" && CurrentUser != nullptr) {
					cout << "Please enter the PostID you want to comment on." << endl;
					string id;
					cin >> id;
					cout << "Please enter the text you want to comment." << endl;
					string text;
					getline(cin, text);
					PostComment(CurrentUser, id, text, PostArray);
					!validcommand;
				}
				else if (Command == "!viewpage" && CurrentUser != nullptr) {
					cout << "Please enter the PageID you want to see." << endl;
					string id;
					cin >> id;
					ViewPage(id, PostArray, UserArray);
					!validcommand;
				}
				else if (Command == "!viewprofile" && CurrentUser != nullptr) {
					ViewProfile(CurrentUser, PostArray, UserArray);
					!validcommand;
				}
				else if (Command == "!sharememory" && CurrentUser != nullptr) {
					cout << "Please enter the post yu want to share as a memory." << endl;
					string id; cin >> id;
					cout << "Please enter the text you want to store with this memory." << endl;
					string text; getline(cin, text);
					ShareMemory(Memories, PostArray, text, id, CurrentUser);
					!validcommand;
				}
				else if (Command == "!viewmemories" && CurrentUser != nullptr) {
					ViewMemories(Memories, CurrentUser, CurrentTime, UserArray);
					!validcommand;
				}
				else if (Command == "!viewhome" && CurrentUser != nullptr) {
					cout << "Viewing " << CurrentUser->GetName() << " homepage ==>" << endl;
					ViewHomefOfUser(CurrentUser, PostArray, UserArray, CurrentTime);
					!validcommand;
				}
				else if (CurrentUser == nullptr) {
					cout << "To get the full potential of this app, please use command !setuser to login.\n" << endl;
					!validcommand;
				}

				getline(cin, Command);
				tolower(Command);

				if (Command != "!viewhome" && Command != "!viewmemories" && Command != "!sharememory" && Command != "!viewprofile" && Command != "!viewpage"
					&& Command != "!postcomment" && Command != "!viewpost" && Command != "!viewprofile" && Command != "!viewlikedpages" &&
					Command != "!viewfriends" && Command != "!viewlikes" && Command != "!like" && Command != "!setuser" && Command != "!help" && Command != "!exit" && Command != "") {
					cout << Command << " not recognized as a valid command." << endl;
				}
				validcommand = 1;

			}
			return "Thank you for Using this trash Application.";
		}
		void RunApp() {
			InitializePostArray(PostArray);
			InitializeUsersArray(UserArray);
			InitializePagesInArray(UserArray);
			InitializeCommentsInPosts(PostArray, UserArray);
			string response;
			response = getcommands(UserArray, PostArray, Memories);
			cout << response;
		}

		~PookieDatingSimulator() {
			for (Post* P : PostArray) {
				if (P != nullptr) {
					delete P;
				}
			}
			for (Memory* M : Memories) {
				if (M != nullptr) {
					delete M;
				}
			}
		}
	};

}
