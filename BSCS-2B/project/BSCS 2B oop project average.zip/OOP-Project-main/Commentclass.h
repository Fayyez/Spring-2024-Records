#pragma once

#include <iostream>
using namespace std;

class Comment {
	string ID;
	string PostedOn;
	string PostedBy;
	string Text;
public:
	Comment(string ID = "", string Posted = "", string Poster = "", string T = "") {
		this->ID = ID;
		PostedOn = Posted;
		PostedBy = Poster;
		Text = T;
	}
	string GetPostedBy() {
		return PostedBy;
	}
	string GetText() {
		return Text;
	}
};
