#include <iostream>
#include <vector>
#include "MemoryClass.h"
using namespace std;



class Entity {
private:
    string ID;
    string Name;
  
public: 
    Entity(string ID = "", string Name = "") : ID(ID), Name(Name) {}
    string GetName() {
        return Name;
    }
    string GetID() {
        return ID;
    }
    virtual void AddComment(Comment* CommentToAdd) = 0;
    virtual void AddPost(Post* post) = 0;
    virtual vector <string> GetFriendList() = 0;
    virtual vector <string> GetLikedPages() = 0;
    virtual ~Entity() {}
};

class Page : public Entity {
private:
    int NumberOfLikes;
    vector <Post*> Posts;
    vector <Comment*> Comments;
public:
    Page(string ID = "", string Name = "", vector<Post*> Posts = {}, int NumberOfLikes = 0, vector<Comment*> Comments = {}) : Entity(ID, Name), NumberOfLikes(NumberOfLikes), Posts(Posts), Comments(Comments) {}

    void IncrementNumberOfLikes() {
        this->NumberOfLikes++;
    }
    void AddComment(Comment* CommentToAdd) {
        Comments.push_back(CommentToAdd);
    }
    void AddPost(Post* post) {
        Posts.push_back(post);
    }
    string GetName() {
        Entity::GetName();
    }
    string GetID() {
        Entity::GetID();
    }
    vector <string> GetFriendList() {
        vector <string > temp = {};
        return temp;
    }
    vector <string> GetLikedPages() {
        vector <string > temp = {};
        return temp;
    }
    ~Page() {
        for (Comment* C : Comments) {
            if (C != nullptr) {
                delete[] C;
            }
        }
    }
};


class User : public Entity {
private:
    vector <string> Friend_List;
    vector <Post*> Liked_Post;
    vector <string> Liked_Pages;
    vector <Post*> Posts;
    vector <Comment*> Comments;
public:
    User(string ID = "", string Name = "", vector<string> FriendList = {}, vector<string> Liked_Pages = {}, vector<Post*> Posts = {}, vector<Post*> Liked_Post = {}, vector<Comment*> Comments = {}): Entity(ID, Name), Friend_List(FriendList),Liked_Post(Liked_Post), Liked_Pages(Liked_Pages),Posts(Posts),Comments(Comments) {}
    void AddComment(Comment* CommentToAdd) {
        Comments.push_back(CommentToAdd);
    }
    void AddPost(Post* post) {
        Posts.push_back(post);
    }
    string GetName() {
        Entity::GetName();
    }
    string GetID() {
        Entity::GetID();
    }
    vector <string> GetFriendList() {
        return Friend_List;
    }
    vector <string> GetLikedPages() {
        return Liked_Pages;
    }
    ~User() {
        for (Comment* C: Comments) {
            delete C;
        }
    }
};






