#pragma once
#include <iostream>
#include "User.h"

class Friend {
private:
	User* Friends;
	int number_of_friends;
public:
	Friend(User* Friend = nullptr, int nof = 0) : Friends(Friend), number_of_friends(nof) {}


};
