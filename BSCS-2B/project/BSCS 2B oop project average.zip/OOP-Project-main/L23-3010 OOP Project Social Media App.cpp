#include "App.h"

int main() {
	l233010::PookieDatingSimulator app;
	app.RunApp();
	return 0;
}