#pragma once
#include <iostream>
#include "Postclass.h"
using namespace std;
class Memory {
private:
    string UserID;
    Post* Memories;
    string Text;
public:
    Memory(string U = "", Post* Memo = nullptr, string T = "") {
        UserID = U;
        Memories = Memo;
        Text = T;
    }
    string GetID() {
        return UserID;
    }
    Post* GetMomories() {
        return Memories;
    }
    string GetTexts() {
        return Text;
    }
};