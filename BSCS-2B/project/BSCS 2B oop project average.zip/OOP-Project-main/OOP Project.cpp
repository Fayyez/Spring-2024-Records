#include <iostream>
#include <cstring>
using namespace std;

class DateTime {
private:
	int date;
	int month;
	int year;
	int hour;
	int min;
public:
	DateTime(int d = 0, int m = 0, int y = 0, int h = 0, int mi = 0) :date(d), month(m), year(y), hour(h), min(mi) {}
};

class Activity {
private:
	string Activity_Style;
	string Value;
public:
	Activity(string ac = "", string val = "") :Activity_Style(ac), Value(val) {
	}
	void SetActivity(string s1, string s2) {
		Activity_Style = s1;
		Value = s2;
	}
	void PrintActivity() {
		cout << " is ";
		cout << Activity_Style;
		cout << " " << Value << endl;
	}
	string getStyle() {
		return Activity_Style;
	}
	string getValue() {
		return Value;
	}
};
void createactivity(Activity& A1) {
	string Activity_Style;
	string Value;
	cout << "1 : Feeling\n2 : Celebrating\n3 : Thinking\n4: Making\n";
	int choice = 0; cin >> choice;
	int ch;
	if (choice == 1)
	{
		Activity_Style = "Feeling";
		cout << "1 : Happy\n2 : Sad\n3 : Excited\n";
		cin >> ch;
		if (ch == 1) {
			Value = "Happy";
		}
		else if (ch == 2) {
			Value = "Sad";
		}
		else if (ch == 3) {
			Value = "Excited";
		}
		else {
			cout << "Invalid choice.";
		}
	}
	else if (choice == 2) {
		Activity_Style = "Celebrating";
		cout << "1 : Birthday\n2 : Success\n3 : Eid\n";
		cin >> ch;
		if (ch == 1) {
			Value = "Birthday";
		}
		else if (ch == 2) {
			Value = "Success";
		}
		else if (ch == 3) {
			Value = "Eid";
		}
		else {
			cout << "Invalid choice.";
		}
	}
	else if (choice == 3) {
		Activity_Style = "Thinking";
		cout << "1 : Life\n2 : Future\n3 : Aakhira\n";
		cin >> ch;
		if (ch == 1) {
			Value = "Life";
		}
		else if (ch == 2) {
			Value = "Future";
		}
		else if (ch == 3) {
			Value = "Aakhira";
		}
		else {
			cout << "Invalid choice.";
		}
	}
	else if (choice == 4) {
		Activity_Style = "Making";
		cout << "1 : Memory\n2 : Art\n3 : Money\n";
		cin >> ch;
		if (ch == 1) {
			Value = "Memory";
		}
		else if (ch == 2) {
			Value = "Art";
		}
		else if (ch == 3) {
			Value = "Money";
		}
		else {
			cout << "Invalid choice.";
		}
	}
	else {
		cout << "Invalid Choice. Default Feeling Selected." << endl;
	}
	A1.SetActivity(Activity_Style, Value);
}

class Post {
private:
	char Description[200];
	string Time;
	Activity Post_Activity;
public:
	Post(char Dis[200] = NULL, string t = "") {
		createactivity(this->Post_Activity);
		Time = t;
		strcpy_s(Description, Dis);
	}
	void PrintPost() {
		cout << "User Posted on :";
		cout << Time << endl;
		cout << endl;
		cout << this->Post_Activity.getStyle() << "\t" << this->Post_Activity.getValue() << endl;
		cout << Description << endl;
	}
	void operator=(Post& P1) {
		strcpy_s(this->Description, P1.Description);
		this->Time = P1.Time;
		this->Post_Activity.SetActivity(P1.Post_Activity.getStyle(), P1.Post_Activity.getValue());
	}
};

class Page {
private:
	string ID;
	string owner;
	Post* Posts;
	int nops;
	int likes;
public:
	Page(string o = "", string own = "", Post* p = nullptr, int nop = 0, int like = 0) : owner(own), Posts(p), likes(like) {
		ID = o;
		nops = nop;
	}
	void addpost() {	
		nops++;
		Post* temp = Posts;
		Posts = new Post[nops];
		cout << "Please enter the Description of the post." << endl;
		char des[200];
		cin.ignore();
		cin.getline(des, 200);
		Post P1(des);
		for (int i = 0; i < nops - 1; i++) {
			Posts[i] = temp[i];
		}
		Posts[nops] = P1;
	}
};

class User {
private:
	string UserID;
	string Name;
	string* Friend_List;
	Post* Liked_Posts;
	Post* Posted;
	Page* Pageowned;
	int number_of_friends;
public:
	User(string UID = "", string name = "", int nof = 0) :UserID(UID), Name(name) {
		Friend_List = nullptr;
		Liked_Posts = nullptr;
		Posted = nullptr;
		Pageowned = nullptr;
		number_of_friends = nof;
	}
	void createpost() {
		cout << "Please enter the Description of the post." << endl;
		char des[200];
		cin.ignore();
		cin.getline(des, 200);
		Post P1(des);
		Posted = new Post(P1);
	}
	void createpage(string pageid = "", string ownername = "", Post* pp = nullptr, int likes = 0) {
		Pageowned = new Page(pageid, ownername, pp, likes);
	}
	void addposttopage() {
		Pageowned->addpost();
	}
	Post* getpost() {
		return Posted;
	}
	void Add_Friend(string UID) {
		number_of_friends++;

	}
	string getUID() {
		return UserID;
	}
	string GetName() {
		return Name;
	}
	~User() {
		delete[] Friend_List;
		delete[] Liked_Posts;
		delete[] Pageowned;
	}
};

class UserArray {
private:
	User* Users;
	int number_of_users;
public:
	UserArray(User* U = nullptr, int n = 0) {
		Users = U;
		number_of_users = n;
	}
	int getnumberofusers() {
		return number_of_users;
	}
	User* getuserarray() {
		return Users;
	}
	UserArray AddUser(string UID, string name) {
		User* arr = new User[number_of_users + 1];
		int i = 0;
		for (i = 0; i < number_of_users; i++) {
			arr[i] = this->Users[i];
		}
		User u(UID, name);
		arr[i] = u;
		UserArray Temp(arr, number_of_users + 1);
		return Temp;
	}
	UserArray DeleteUser() {
		string UID;
		cout << "Please enter the UID of the user you want to delete." << endl;
		cin >> UID;

		for (int i = 0; i < number_of_users; i++) {
			if (this->Users[i].getUID() == UID) {
				for (int j = i; j < number_of_users - 1; j++) {
					this->Users[j] = this->Users[j + 1];
				}
			}
		}
		UserArray Temp(Users, number_of_users - 1);
		return Temp;
	}
	void Print_User_Data() {
		for (int i = 0; i < number_of_users; i++) {
			cout << this->Users[i].getUID() << "\t" << this->Users[i].GetName() << endl;
		}
	}
};

User ActivateUser(UserArray& U) {
	int n = U.getnumberofusers();
	bool found = 0;
	int i = 0;
	cout << "Please select one user from list." << endl;
	string val;
	cin.ignore();
	cin >> val;
	while (found == 0 && i < n) {
		
		if (U.getuserarray()[i].getUID() == val) {
			cout << "User " << U.getuserarray()[i].GetName() << " is now active user." << endl;
			return U.getuserarray()[i];
		}
		i++;
	}
}

int main() {
	UserArray U1;
	U1 = U1.AddUser("U01", "Faheem");
	U1 = U1.AddUser("U02", "Sarwar");
	U1 = U1.AddUser("U03", "Hello");
	U1 = U1.AddUser("U04", "Meown");
	User Active = ActivateUser(U1);
	Active.createpost();
	Active.getpost()->PrintPost();
	Active.createpage("P01",Active.GetName());
	Active.addposttopage();
	return 0;
}