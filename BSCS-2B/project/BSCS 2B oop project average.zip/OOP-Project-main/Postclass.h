#include <iostream>
#include <vector>
#include "ActivityClass.h"
#include "TimeClass.h"
#include "CommentClass.h"
using namespace std;



class Post {
private:
	string ID;
	Time PostTime;
	string Description;
	Activity* PostActivity;
	string Owner;
	vector <string> Liked_By;
	vector<Comment*> Comments;
public:
	Post(string i = "",int day = 0,int mon = 0,int yea = 0,string d = "",Activity* A = nullptr,string own = "", vector<string> Likers = {}, vector<Comment*> C = {}) {
		ID = i;
		PostTime = Time(day, mon, yea);
		Description = d;
		PostActivity = A;
		Owner = own;
		Liked_By = Likers;
		Comments = C;
	}
	string GetID() {
		return ID;
	}
	string GetDescription() {
		return Description;
	}
	string GetOwner() {
		return Owner;
	}
	Activity* GetActivity() {
		return PostActivity;
	}
	Time GetTime() {
		return PostTime;
	}
	vector <Comment*> GetComments() {
		return Comments;
	}
	vector <string> GetLikedBy() {
		return Liked_By;
	}
	void AddComment(Comment* CommentToAdd) {
		Comments.push_back(CommentToAdd);
	}
	void SetLikers(vector <string> Likers) {
		this->Liked_By = Likers;
	}
	~Post() {}
};