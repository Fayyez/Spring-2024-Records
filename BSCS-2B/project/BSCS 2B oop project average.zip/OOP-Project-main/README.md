# OOP-Project
Social Media Clone (Console Based)
App Name : PookieDatingSimulator
Creator : Faheem Sarwar

Could not have made this app without the assistance if my beloved TA Fayyez Farrukh (https://github.com/Fayyez) Definately not doing this for extra marks.
This is my project for OOP course.

Just download the files and run the .sln
You would need a cpp compiler as this is not a compiled version. (will be posting once app is final).

Will be implementing more features in the future such as creating a user, adding passwords for security, creating a post, possibally adding online service for usage among friends. If i didnot lose interest.

Would want to keep this work in progress alone as it might be a great source of learning for me. 

Feel free to use this application.
