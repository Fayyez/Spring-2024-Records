#pragma once
#include <iostream>
using namespace std;


class Time {
private:
	int date;
	int month;
	int year;
public:
	Time(int D = 0, int M = 0, int Y = 0) {
		date = D;
		month = M;
		year = Y;
	}
	void PrintTime() {
		cout << date << " / " << month << " / " << year << endl;
	}
	int GetDate() {
		return date;
	}
	int GetYear() {
		return year;
	}
	int GetMonth() {
		return month;
	}

};
