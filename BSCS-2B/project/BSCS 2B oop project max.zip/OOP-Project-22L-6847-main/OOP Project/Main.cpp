#include<iostream>
#include "SocialNetworkApp.h"

using namespace std;

int main()
{
	SocialNetworkApp App;

	App.Run();
}