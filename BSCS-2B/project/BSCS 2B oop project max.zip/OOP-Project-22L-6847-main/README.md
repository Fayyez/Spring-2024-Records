# Introduction:
SocialNetworkApp is a social media platform just like facebook that I made as my final semester project for the course of Object Oriented Programming in the second semester of my bachelor's degree in computer science. The is 
OOP Project built in C++ using SFML library for GUI with implementations and usecases for all major concept of OOP , i.e, inheritence, encapsulation and composition and aggregation.
