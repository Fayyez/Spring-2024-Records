#include<iostream>
#include<fstream>
#include"Activity.h"

using namespace std;


ACTIVITY::ACTIVITY()
{
	type = 0;
	value = 0;
}
ACTIVITY::~ACTIVITY()
{
	delete[]value;
}
void ACTIVITY::Print()
{
	if (type == 1)
	{
		cout << "feeling " << value;

	}

	else if (type == 2)
	{
		cout << "thinking about " << value;
	}
	else if (type == 3)
	{
		cout << "Making " << value;
	}
	else if (type == 4)
	{
		cout << "celebrating " << value;
	}
}

void ACTIVITY::ReadDataFromFile(ifstream& inp)
{
	char temp[100];
	inp >> type;
	inp.getline(temp, '100');
	SUPPORT::CopyString(temp, value);
}

void ACTIVITY::SetValue(char* text)
{
	SUPPORT::CopyString(text, value);
}
