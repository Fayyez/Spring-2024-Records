#pragma once
#ifndef ACTIVITY_H
#define ACTIVITY_H

#include<iostream>
using namespace std;
#include "Support.h"
#include"Object.h"

class ACTIVITY {
    int type;
    char* value;
public:
    ACTIVITY();
    ~ACTIVITY();
    void Print();
    void ReadDataFromFile(ifstream& inp);
    void SetValue(char* text);
};

#endif 
