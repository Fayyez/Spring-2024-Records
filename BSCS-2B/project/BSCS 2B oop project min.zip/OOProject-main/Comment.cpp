#include<iostream>
#include"Comment.h"
using namespace std;


    int COMMENT::TotalComments = 0;

	COMMENT::COMMENT(OBJECT* CurrentUser, char* txt)
	{
		char* IdForNewComment = SUPPORT::ConcateIntAndString("c", TotalComments + 1);
		Text = txt;
		CommentBy = CurrentUser;
		Id = IdForNewComment;
	}

	COMMENT::COMMENT()
	{
		CommentBy = 0;
		Text = 0;
		Id = 0;
	}
	COMMENT::~COMMENT()
	{
		delete[]CommentBy;
		delete[]Text;
		delete[]Id;
	}

	void COMMENT::SetValues(char* idStr, char* textStr, OBJECT* commentByPtr)
	{
		CommentBy = commentByPtr;
		SUPPORT::CopyString(textStr, Text);
		SUPPORT::CopyString(idStr, Id);
		TotalComments++;
	}

	void COMMENT::Print()
	{
		CommentBy->PrintForHome();
		cout << " wrote:" << Text << endl;
	}

