#pragma once
#ifndef COMMENT_H
#define COMMENT_H

#include "Object.h" 
#include "Support.h"
#include<iostream>
using namespace std;

class COMMENT {
    OBJECT* CommentBy; 
    char* Text;
    char* Id;
    static int TotalComments;

public:
    COMMENT(OBJECT* CurrentUser, char* txt);
    COMMENT();
    ~COMMENT();
    void SetValues(char* id, char* text, OBJECT* commentByPtr);
    void Print();
};

#endif 
