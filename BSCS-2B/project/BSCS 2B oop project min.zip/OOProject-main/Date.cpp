
#include<iostream>
#include<fstream>
#include"Date.h"

using namespace std;


DATE DATE::CurrentDate;

DATE::DATE()
{
	day = 0;
	month = 0;
	year = 0;
}

void DATE::ReadDataFromFile(ifstream& inp)
{
	inp >> day;
	inp >> month;
	inp >> year;
}

bool DATE::compare(const DATE& rhs, bool isMemory)
{
	if (isMemory == false)
	{
		if (year != rhs.year)
		{
			return false;
		}

		else if (month == rhs.month)
		{
			if (day == rhs.day)
			{
				return true;
			}
			else if (day + 1 == rhs.day || day - 1 == rhs.day)
			{
				return true;
			}
			else
				return false;
		}
		else
			return false;
	}
	else
	{
		if (year == rhs.year)
		{
			return false;
		}
		else
		{
			if (month == rhs.month)
			{
				if (day == rhs.day)
				{
					return true;
				}
				else if (day + 1 == rhs.day || day - 1 == rhs.day)
				{
					return true;
				}
				else
					return false;
			}
			else
				return false;
		}
	}
}

int DATE::YearDiff(DATE lhs, DATE rhs)
{
	int ans;
	ans = lhs.year - rhs.year;
	if (ans < 0)
	{
		ans = -ans;
	}
	return ans;
}

void DATE::Print()
{
	cout << day << "/" << month << "/" << year;
}

void DATE::SetData(int d, int m, int y)
{
	day = d;
	month = m;
	year = y;

}


