#pragma once
#ifndef DATE_H
#define DATE_H

#include<fstream>
#include<iostream>
using namespace std;

class DATE
{
    int day;
    int month;
    int year;

public:
    static DATE CurrentDate;
    DATE();
    void ReadDataFromFile(ifstream& inp);
    bool compare(const DATE& rhs, bool isMemory);
    static int YearDiff(DATE lhs, DATE rhs);
    void Print();
    void SetData(int d, int m, int y);
};

#endif 
