#include<iostream>
#include<fstream>
#include"Manager.h"

using namespace std;



int MANAGER::totalUsers = 0;
int MANAGER::totalPages = 0;
int MANAGER::totalPosts = 0;
int MANAGER::totalComments = 0;

	MANAGER::MANAGER()
	{
		pages = 0;
		users = 0;
		posts = 0;
		comments = 0;
	}
	MANAGER::~MANAGER()
	{
		for (int i = 0; i < totalPages; i++)
		{
			if (pages[i] != 0)
				delete pages[i];
		}
		delete[]pages;

		for (int i = 0; i < totalUsers; i++)
		{
			if (users[i] != 0)
				delete users[i];
		}
		delete[]users;


		for (int i = 0; i < totalPosts; i++)
		{
			if (posts[i] != 0)
				delete posts[i];
		}
		delete[]posts;
	}

	void MANAGER::LoadPages(char* filename)
	{
		ifstream inp;
		inp.open(filename);
		if (inp)
		{
			inp >> totalPages;


			pages = new PAGES * [totalPages];
			for (int i = 0; i < totalPages; i++)
			{
				pages[i] = new PAGES;
				pages[i]->ReadDataFromFile(inp);
			}

			inp.close();
		}
	}

	void MANAGER::LoadUsers(char* filename)
	{
		ifstream inp;
		inp.open(filename);
		if (inp)
		{
			inp >> totalUsers;

			users = new USERS * [totalUsers];
			char*** friendList = new char** [totalUsers];
			char temp[50];

			for (int i = 0; i < totalUsers; i++)
			{
				users[i] = new USERS;
				users[i]->ReadDataFromFile(inp);
				friendList[i] = new char* [10];
				for (int h = 0; h < 10; h++)
				{
					friendList[i][h] = 0;
				}
				for (int j = 0; j < 10; j++)
				{
					inp >> temp;
					if (SUPPORT::compareString(temp, "-1"))
					{
						break;
					}
					else
						SUPPORT::CopyString(temp, friendList[i][j]);
				}
				inp.ignore();

				PAGES* pointer;
				for (int j = 0; j < 10; j++)
				{
					inp >> temp;
					if (SUPPORT::compareString(temp, "-1"))
					{
						break;
					}
					else
					{
						pointer = GetPageFromId(temp);
						users[i]->SetPage(pointer);
					}
				}

			}

			//associate friends
			USERS *ptr;
			for (int j = 0; j < totalUsers; j++)
			{
				for (int k = 0; k < 10; k++)
				{
					if (friendList[j][k] == 0)
					{
						break;
					}

					ptr = GetUserFromId(friendList[j][k]);
					users[j]->SetFriend(ptr);
				}
			}

			//deallocate the 3d pointer
			for (int h = 0; h < totalUsers; h++)
			{
				if (friendList[h])
				{
					for (int g = 0; g < 10; g++)
					{
						if (friendList[h][g])
							delete[]friendList[h][g];
					}
					delete[] friendList[h];
				}

			}

			inp.close();

			if (friendList)
			{
				delete[]friendList;
			}

		}


	}

	void MANAGER::PrintUser(char* str)
	{
		cout << "Set Current User " << str << endl;
		USERS* ptr = GetUserFromId(str);
		ptr->Print();
	}

	USERS* MANAGER::GetUserFromId(const char* str)
	{
		for (int i = 0; i < totalUsers; i++)
		{
			if (SUPPORT::compareString(str, users[i]->GetId()))
			{
				return users[i];
			}
		}
		return 0;
	}

	PAGES* MANAGER::GetPageFromId(char* str)
	{
		for (int i = 0; i < totalPages; i++)
		{
			if (SUPPORT::compareString(str, pages[i]->GetId()))
			{
				return pages[i];
			}
		}
		return 0;
	}

	OBJECT* MANAGER::GetObjectById(char* str)
	{
		if (str[0] == 'u')
		{
			return GetUserFromId(str);
		}
		else if (str[0] == 'p')
		{
			return GetPageFromId(str);
		}
		else
			return 0;
	}

	POST* MANAGER::GetPostById(char* str)
	{
		for (int i = 0; i < totalPosts; i++)
		{
			if (SUPPORT::compareString(str, posts[i]->GetId()))
			{
				return posts[i];
			}
		}

		return 0;
	}

	void MANAGER::LoadPosts(char* filename)
	{
		ifstream inp;
		inp.open(filename);
		char temp[100];
		if (inp)
		{
			inp >> totalPosts;
			posts = new POST * [totalPosts];
			for (int i = 0; i < totalPosts; i++)
			{
				posts[i] = new POST;
				posts[i]->ReadDataFromFile(inp);
				inp >> temp;
				OBJECT* sharedBy = GetObjectById(temp);
				posts[i]->SetSharedBy(sharedBy);
				sharedBy->AddPostToTimeline(posts[i]);
				inp >> temp;

				for (int j = 0; temp[0] != '-'; j++)
				{
					posts[i]->SetLikedBy(GetObjectById(temp));
					inp.ignore();
					inp >> temp;
				}
			}
		}
		inp.close();
	}

	void MANAGER::LoadComments(char* filename)
	{
		ifstream inp;
		inp.open(filename);

		if (inp)
		{
			inp >> totalComments;

			char tempId[100], strText[100], temp[50], tempPost[50];
			OBJECT* commentBy;

			comments = new COMMENT * [totalComments];

			for (int i = 0; i < totalComments; i++)
			{
				comments[i] = new COMMENT;
				inp >> tempId;
				inp.ignore();

				inp >> tempPost;


				inp >> temp;
				commentBy = GetObjectById(temp);
				inp.ignore();

				inp.getline(strText, 100);

				comments[i]->SetValues(tempId, strText, commentBy);

				POST* ptr = GetPostById(tempPost);
				ptr->AddComment(comments[i]);
			}
			inp.close();
		}
	}
	
	void MANAGER::ViewFriendList(USERS* currentUser)
	{
		cout << "------------------------------------------------------------------------------------------------" << endl;
		cout << "Command	ViewFriendList" << endl;
		cout << "------------------------------------------------------------------------------------------------" << endl;

		currentUser->ViewFriendList();
	}
	
	void MANAGER::ViewLikedPages(USERS* currentUser)
	{
		cout << "------------------------------------------------------------------------------------------------" << endl;
		cout << "Command	ViewLikedPages" << endl;
		cout << "------------------------------------------------------------------------------------------------" << endl;

		currentUser->ViewLikedPages();
	}

	void MANAGER::ViewHome(USERS* currentUser, DATE currentDate)
	{
		cout << "------------------------------------------------------------------------------------------------" << endl;
		cout << "Command	ViewHome" << endl;
		cout << "------------------------------------------------------------------------------------------------" << endl;

		currentUser->HomePage(currentDate);
	}

	void MANAGER::ViewTimeline(USERS* currentUser)
	{
		cout << "------------------------------------------------------------------------------------------------" << endl;
		cout << "Command	ViewTimeline" << endl;
		cout << "------------------------------------------------------------------------------------------------" << endl;

		currentUser->ViewTimeline();
	}

	void MANAGER::ViewLikedList(char* str)
	{
		cout << "------------------------------------------------------------------------------------------------" << endl;
		cout << "Command	ViewLikedList(" << str << ")" << endl;
		cout << "------------------------------------------------------------------------------------------------" << endl;

		POST* post = GetPostById(str);
		post->ViewLikedList();
	}

	void MANAGER::LikePost(USERS* currentUser, char* post)
	{
		cout << "------------------------------------------------------------------------------------------------" << endl;
		cout << "Command	LikePost(" << post << ")" << endl;

		POST* postToLike = GetPostById(post);
		currentUser->LikePost(postToLike);
	}

	void MANAGER::AddComment(USERS* CurrentUser, char* post, char* txt)
	{
		cout << "------------------------------------------------------------------------------------------------" << endl;
		cout << "Command	PostComment(" << post << " , " << txt << ")" << endl;

		POST* currentPost = GetPostById(post);
		COMMENT* newComment = new COMMENT(CurrentUser, txt);
		currentPost->AddComment(newComment);
	}

	void MANAGER::ViewPost(char* post)
	{
		cout << "------------------------------------------------------------------------------------------------" << endl;
		cout << "Command	ViewPost(" << post << ")" << endl;
		cout << "------------------------------------------------------------------------------------------------" << endl;
		bool temp = false;
		POST* currentPost = GetPostById(post);
		currentPost->Print(temp);
	}

	void MANAGER::ViewMemory(USERS* currentUser, DATE CurrentDate)
	{
		cout << "------------------------------------------------------------------------------------------------" << endl;
		cout << "Command	SeeYourMemory()" << endl;
		cout << "------------------------------------------------------------------------------------------------" << endl;

		currentUser->SeeMemory(CurrentDate);
	}

	void MANAGER::ShareMemory(USERS* currentUSer, char* originalPostId, char* txt, DATE currentDate)
	{
		cout << "------------------------------------------------------------------------------------------------" << endl;
		cout << "Command	ShareMemory(" << originalPostId << "," << "\"" << txt << "\")" << endl;

		POST* originalPost = GetPostById(originalPostId);
		MEMORY* newPostPtr = new MEMORY(originalPost, txt, currentUSer, currentDate);
		currentUSer->AddPostToTimeline(newPostPtr);
	}

	void MANAGER::ViewPage(char* pageName)
	{
		cout << "------------------------------------------------------------------------------------------------" << endl;
		cout << "Command	ViewPage(" << pageName << ")" << endl;
		cout << "------------------------------------------------------------------------------------------------" << endl;

		PAGES* currentPage = GetPageFromId(pageName);
		currentPage->PrintForHome();
		cout << endl;
		currentPage->ViewTimeline();
	}

	void MANAGER::Load()
	{
		LoadPages(const_cast < char*>("PAGES.txt"));
		LoadUsers(const_cast < char*>("USERS.txt"));
		LoadPosts(const_cast < char*>("POSTS.txt"));
		LoadComments(const_cast < char*>("COMMENTS.txt"));
	}

	void MANAGER::Run(char* str)
	{
		Load();
		USERS* currentUser = GetUserFromId(str);
		DATE::CurrentDate.SetData(15, 11, 2017);

		PrintUser(str);
		ViewFriendList(currentUser);
		ViewLikedPages(currentUser);

		//  ALHAMDULLILAH -----------------------------------------------------------PHASE 1---------------------------------------------------------------
		//  INSHA ALLAH -------------------------------------------------------------PHASE 2---------------------------------------------------------------

		ViewHome(currentUser, DATE::CurrentDate);
		ViewTimeline(currentUser);
		ViewLikedList(const_cast <char*>("post5"));

		//command LikePost(Post5)

		LikePost(currentUser, const_cast < char*> ("post5"));
		ViewLikedList(const_cast < char*>("post5"));


		//command add comment
		ViewPost(const_cast < char*>("post4"));
		AddComment(currentUser, const_cast < char*>("post4"), const_cast < char*>("My Best Wishes."));
		ViewPost(const_cast < char*>("post4"));

		ViewPost(const_cast < char*>("post8"));
		AddComment(currentUser, const_cast < char*>("post8"), const_cast < char*>("Thanks for the wishes."));
		ViewPost(const_cast < char*>("post8"));

		//View memory
		ViewMemory(currentUser, DATE::CurrentDate);

		ShareMemory(currentUser, const_cast < char*>("post10"), const_cast < char*>("Never thought I will be specialist in this field") , DATE::CurrentDate);
		ViewTimeline(currentUser);

		ViewPage(const_cast < char*>("p1"));

		
	}


	int main()
	{
		MANAGER obj;
		obj.Run(const_cast <char*>("u7"));

		system("pause");
	}