#pragma once
#ifndef MANAGER_H
#define MANAGER_H

#include<iostream>
using namespace std;
#include"Support.h"
#include "User.h"
#include "Post.h"
#include "Date.h"
#include "Activity.h"
#include "Memory.h"
#include "Comment.h"
#include "Page.h"


class MANAGER
{
    PAGES** pages;
    USERS** users;
    POST** posts;
    COMMENT** comments;

    static int totalUsers;
    static int totalPages;
    static int totalPosts;
    static int totalComments;

public:
    MANAGER();
    ~MANAGER();
    void LoadPages(char* filename);
    void LoadUsers(char* filename);
    void PrintUser(char* str);
    USERS* GetUserFromId(const char* str);
    PAGES* GetPageFromId(char* str);
    OBJECT* GetObjectById(char* str);
    POST* GetPostById(char* str);
    void LoadPosts(char* filename);
    void LoadComments(char* filename);
    void ViewFriendList(USERS* currentUser);
    void ViewLikedPages(USERS* currentUser);
    void ViewHome(USERS* currentUser, DATE currentDate);
    void ViewTimeline(USERS* currentUser);
    void ViewLikedList(char* str);
    void LikePost(USERS* currentUser, char* post);
    void AddComment(USERS* CurrentUser, char* post, char* txt);
    void ViewPost(char* post);
    void ViewMemory(USERS* currentUser, DATE CurrentDate);
    void ShareMemory(USERS* currentUSer, char* originalPostId, char* txt, DATE currentDate);
    void ViewPage(char* pageName);
    void Load();
    void Run(char* str);
};

#endif 
