#include<iostream>
#include"Memory.h"
using namespace std;




	MEMORY::MEMORY()
	{
		Original = 0;
	}
	MEMORY::~MEMORY()
	{
		delete Original;
	}

	MEMORY::MEMORY(POST*& oldPost, const char* text, OBJECT* userptr, DATE currentDate) :POST(text, userptr, currentDate)
	{
		Original = oldPost;
	}
	void MEMORY::Print(bool& flag)
	{
		cout << "Shared a memory (" << DATE::YearDiff(Original->GetSharedDate(), GetSharedDate()) << " years) ago" << endl;;
		Original->Print(flag);
		flag = true;
	}

	POST* MEMORY::GetOriginalPost()
	{
		return Original;
	}
