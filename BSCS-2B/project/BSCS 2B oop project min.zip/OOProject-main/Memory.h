#pragma once
#ifndef MEMORY_H
#define MEMORY_H

#include<iostream>
using namespace std;
#include "Date.h"
#include "Post.h"
#include"Object.h"


class MEMORY : public POST
{
    POST* Original;

public:
    MEMORY();
    ~MEMORY();
    MEMORY(POST*& oldPost, const char* text, OBJECT* userptr, DATE currentDate);
    void Print(bool& flag);
    POST* GetOriginalPost();
};

#endif 
