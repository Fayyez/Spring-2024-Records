#include<iostream>
#include"Object.h"

using namespace std;


	OBJECT::OBJECT()
	{
		Id = 0;
		username = 0;
	}
    OBJECT::~OBJECT()
	{
		delete[]Id;
	}
	
	char* OBJECT::GetID() {
		return Id;
	}
	void OBJECT::SetID(char* ptr) {
		Id = ptr;
	}
	 void OBJECT::Print()
	{
		cout << Id;
	}
	 void OBJECT::PrintForHome()
	{
		cout << "Error	Not Found!!!!!!!!" << endl;
	}
	void OBJECT::AddPostToTimeline(POST* ptr)
	{
		cout << "Error	Not Found!!!!!!!!" << endl;

	}

