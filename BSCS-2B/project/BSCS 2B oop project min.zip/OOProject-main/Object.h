#pragma once
#ifndef OBJECT_H
#define OBJECT_H

#include <iostream>


class POST;

class OBJECT {
    char* Id;
    char* username;

public:
    OBJECT();
    virtual ~OBJECT();
    char* GetID();
    void SetID(char* id);
    void Print();
    virtual void PrintForHome();
    virtual void AddPostToTimeline(POST* ptr);
};

#endif 