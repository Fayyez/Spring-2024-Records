#include<iostream>
#include <fstream>
#include"Page.h"

using namespace std;


PAGES::PAGES()
{
	Title = 0;
	timeline = 0;
	ID = 0;
	totalTimeline = 0;
}

PAGES::~PAGES()
{
	delete[] Title;
	if (timeline != 0)
		delete[] timeline;
}

void PAGES::ReadDataFromFile(ifstream& inp)
{
	char temp[50];
	inp >> temp;
	char* ptr;
	SUPPORT::CopyString(temp, ptr);
	SetID(ptr);
	inp.ignore();
	inp.getline(temp, 50, '\n');
	SUPPORT::CopyString(temp, Title);
	delete[]ptr;
	
}

void PAGES::PrintForHome()
{
	cout << Title;
}

void PAGES::AddPostToTimeline(POST* ptr)
{
	if (totalTimeline == 0)
	{
		timeline = new POST * [10];
		for (int i = 0; i < 10; i++)
		{
			timeline[i] = 0;
		}
		timeline[totalTimeline] = ptr;
		totalTimeline++;
	}
	else
	{
		timeline[totalTimeline] = ptr;
		totalTimeline++;
	}
}

void PAGES::CheckDate(DATE CurrentDate, bool isMemory)
{
	bool temp = false;
	for (int i = 0; i < totalTimeline; i++)
	{
		if (timeline[i]->CompareDate(CurrentDate, isMemory))
		{
			timeline[i]->Print(temp);
		}
	}
}

void PAGES::Print()
{

	cout << this->GetID() << "\t" << Title << endl;
}

void PAGES::ViewTimeline()
{
	bool temp = false;
	if (timeline != 0)
	{
		for (int i = 0; i < totalTimeline; i++)
		{
			timeline[i]->Print(temp);
		}
	}
}


char* PAGES::GetId()
{
	return this->GetID();
}


