#pragma once
#ifndef PAGES_H
#define PAGES_H


#include<iostream>
using namespace std;
#include "Support.h"
#include"Date.h"
#include "Post.h"
#include"Object.h"



class PAGES : public OBJECT
{
    char* Title;
    POST** timeline;
    char* ID;
    int totalTimeline;

public:
    PAGES();
    ~PAGES();
    void ReadDataFromFile(ifstream& inp);
    void PrintForHome();
    void AddPostToTimeline(POST* ptr);
    void CheckDate(DATE CurrentDate, bool isMemory);
    void Print();
    void ViewTimeline();
    char* GetId();
};

#endif 
