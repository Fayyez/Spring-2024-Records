#include<iostream>
#include<fstream>
#include"Post.h"

using namespace std;



int POST::TotalPosts = 0;

	POST::~POST()
	{
		delete[] Id;
		delete[] text;
		if (LikedBy != 0)
			delete[] LikedBy;
		if (comments != 0)
			delete[] comments;
		if (activity != 0)
			delete activity;
	}

	POST::POST(const char* txt, OBJECT* SharedBy, DATE currentDate)
	{

		activity = 0;
		char* IdForNewPost = SUPPORT::ConcateIntAndString("post", TotalPosts + 1);

		SUPPORT::CopyString(IdForNewPost, Id);
		SUPPORT::CopyString(txt, text);
		sharedBy = SharedBy;
		sharedDate = currentDate;
		totalComment = 0;
		totalLikedBy = 0;
	}

	POST::POST()
	{
		Id = 0;
		text = 0;
		sharedBy = 0;
		LikedBy = 0;
		comments = 0;
		activity = 0;
		totalComment = 0;
		totalLikedBy = 0;
	}


	void POST::SetSharedBy(OBJECT* ptr)
	{
		sharedBy = ptr;
	}
	void POST::SetLikedBy(OBJECT* ptr)
	{
		if (totalLikedBy == 0)
		{
			LikedBy = new OBJECT * [10];
			for (int i = 0; i < 10; i++)
			{
				LikedBy[i] = 0;
			}
			LikedBy[totalLikedBy] = ptr;
			totalLikedBy++;
		}
		else
		{
			LikedBy[totalLikedBy] = ptr;
			totalLikedBy++;
		}
	}

	void POST::AddComment(COMMENT* ptr)
	{
		if (totalComment == 0)
		{
			comments = new COMMENT * [10];
			for (int i = 0; i < 10; i++)
			{
				comments[i] = 0;
			}
			comments[totalComment] = ptr;
			totalComment++;
		}
		else
		{
			comments[totalComment] = ptr;
			totalComment++;
		}
	}

	bool POST::CompareDate(DATE currentDate, bool isMemory)
	{
		if (currentDate.compare(sharedDate, isMemory))
		{
			return true;
		}
		else
			return false;
	}



	DATE POST::GetSharedDate()
	{
		return sharedDate;
	}

	char* POST::GetId()
	{
		return Id;
	}

	void POST::ReadDataFromFile(ifstream& inp)
	{
		int activityId = 0;
		inp >> activityId;
		char temp[100];
		inp >> temp;
		SUPPORT::CopyString(temp, Id);
		sharedDate.ReadDataFromFile(inp);
		inp.ignore();
		inp.getline(temp, 100, '\n');
		SUPPORT::CopyString(temp, text);
		if (activityId == 2)
		{
			activity = new ACTIVITY;
			activity->ReadDataFromFile(inp);
		}
		TotalPosts++;


	}
	void POST::Print(bool& flag)
	{

		sharedBy->PrintForHome();
		cout << " ";
		if (activity != 0)
		{
			activity->Print();
		}
		cout << endl;
		cout << "\"" << text << "\"";
		cout << " (";
		sharedDate.Print();
		cout << ") " << endl << "\t";
		for (int i = 0; i < totalComment; i++)
		{
			comments[i]->Print();
			cout << "\t";
		}
		cout << endl;

	}
	void POST::Print()
	{
		sharedBy->PrintForHome();
		cout << " ";
		if (activity != 0)
		{
			activity->Print();
		}
		cout << endl;
		cout << "\"" << text << "\"";
		cout << " (";
		cout << ") " << endl << "\t";
		for (int i = 0; i < totalComment; i++)
		{
			comments[i]->Print();
			cout << "\t";
		}
		cout << endl;
	}
	void POST::ViewLikedList()
	{
		if (LikedBy != 0)
		{
			cout << "-----------------------------------------------------------------------------------------" << endl;
			for (int i = 0; i < totalLikedBy; i++)
			{
				LikedBy[i]->Print();
				cout << endl;
			}
		}
	}


