#pragma once
#ifndef POST_H
#define POST_H

#include<iostream>
using namespace std;
#include"Support.h"
#include"Date.h"
#include "Object.h"
#include "Comment.h"
#include"Activity.h"


class POST
{
    char* Id;
    char* text;
    DATE sharedDate;
    OBJECT* sharedBy;
    OBJECT** LikedBy;
    COMMENT** comments;
    ACTIVITY* activity;
    int totalLikedBy;
    int totalComment;

    static int TotalPosts;

public:
    POST();
    ~POST();
    POST(const char* txt, OBJECT* SharedBy, DATE currentDate);
    void ReadDataFromFile(ifstream& inp);
    void SetSharedBy(OBJECT* user);
    void AddComment(COMMENT* c);
    bool CompareDate(DATE currentDate, bool isMemory);
    void SetLikedBy(OBJECT* user);
    DATE GetSharedDate();
    char* GetId();
    void Print(bool& flag);
    void ViewLikedList();
    void Print();
};

#endif 

