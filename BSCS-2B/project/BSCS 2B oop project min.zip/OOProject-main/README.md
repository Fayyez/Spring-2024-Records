# OOProject
Social media app
An example of social media app(facebook) with basic functionality.
