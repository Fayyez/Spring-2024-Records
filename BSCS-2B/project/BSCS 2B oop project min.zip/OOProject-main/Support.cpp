#include<iostream>
#include"Support.h"
using namespace std;


	
	 void SUPPORT::CopyString(const char* temp, char*& str)
	{
		int len = strlen(temp);
		str = new char[len + 1];
		for (int i = 0; i <= len; i++)
		{
			str[i] = temp[i];
		}
	}

	 bool SUPPORT::compareString(const char* str, const char* str2)
	{
		bool flag = true;
		for (int i = 0; i < strlen(str); i++)
		{
			if (str[i] != str2[i])
			{
				flag = false;
			}
		}
		return flag;
	}

	char* SUPPORT::ConcateIntAndString(const char* str, int num)
	{
		int str_len = strlen(str);

		int num_copy = num;
		int num_len = 0;
		while (num_copy > 0) { // used to find total digits of num
			num_copy /= 10;
			num_len++;
		}

		char* result = new char[str_len + num_len + 1];

		int i = 0;
		while (str[i] != '\0') {
			result[i] = str[i];
			i++;
		}

		int j = i + num_len - 1;
		while (num > 0) {
			result[j] = '0' + (num % 10);//adds rightmost digit of num(eg:num=70 then 0 is added)
			num /= 10;// change value of num to next digit
			j--;//index j to move to the left in the result to add next digit
		}

		result[str_len + num_len] = '\0';
		return result;
	}

