#pragma once
#ifndef SUPPORT_H
#define SUPPORT_H

#include<iostream>
using namespace std;

class SUPPORT
{
public:
    static void CopyString(const char* temp, char*& str);
    static bool compareString(const char* str, const char* str2);
    static char* ConcateIntAndString(const char* str, int num);//made for id
};

#endif 
