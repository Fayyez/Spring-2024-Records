#include<iostream>
#include<fstream>
#include"Post.h"
#include"User.h"

using namespace std;



	USERS::USERS()
	{
		Fname = 0;
		Lname = 0;
		LikedPages = nullptr;
		FriendList = nullptr;
		timeline = nullptr;
		totalTimeline = 0;
		numPages = 0;
		numFriends = 0;
	}

	USERS::~USERS()
	{
		delete[] Fname;
		delete[] Lname;
		if (LikedPages != 0)
			delete[] LikedPages;
		if (FriendList != 0)
			delete[] FriendList;
		if (timeline != 0)
			delete[] timeline;
	}


	void USERS::USERS::ReadDataFromFile(ifstream& inp)
	{
		char temp[50];
		inp >> temp;
		char* ptr;
		SUPPORT::CopyString(temp, ptr);
		SetID(ptr);
		inp >> temp;
		SUPPORT::CopyString(temp, Fname);
		inp >> temp;
		SUPPORT::CopyString(temp, Lname);
	}

	void USERS::SetPage(PAGES* ptr)
	{
		if (numPages == 0)
		{
			LikedPages = new PAGES * [10];
			for (int i = 0; i < 10; i++)
			{
				LikedPages[i] = 0;
			}
		}
		LikedPages[numPages] = ptr;
		numPages++;
	}

	void USERS::CheckDate(DATE CurrentDate, bool isMemory)
	{
		bool temp = false;
		for (int i = 0; i < totalTimeline; i++)
		{
			if (timeline[i]->CompareDate(CurrentDate, isMemory))
			{
				timeline[i]->Print(temp);
			}
		}
	}

	void USERS::LikePost(POST* post)
	{
		post->SetLikedBy(this);
	}

	void USERS::HomePage(DATE currentDate)
	{

		cout << "------------------------------------------------------------------------------" << endl;
		if (FriendList != 0)
		{
			for (int i = 0; i < numFriends; i++)
			{
				FriendList[i]->CheckDate(currentDate, false);
			}
		}

		if (LikedPages != 0)
		{
			for (int i = 0; i < numPages; i++)
			{
				LikedPages[i]->CheckDate(currentDate, false);
			}
		}
		cout << endl;
	}

	void USERS::ViewTimeline()
	{
		if (timeline != 0)
		{
			cout << "---------------------------------------------------------------------------------" << endl;
			for (int i = 0; i < totalTimeline; i++)
			{
				if (timeline[i] != 0)
				{
					bool IsNewPost = false;
					timeline[i]->Print(IsNewPost);
					if (IsNewPost)
					{
						timeline[i]->Print();
					}
				}
			}
		}
	}

	void USERS::SeeMemory(DATE currentDate)
	{
		bool temp = false;
		for (int i = 0; i < totalTimeline; i++)
		{
			if (timeline[i] != 0)
			{
				if (timeline[i]->CompareDate(currentDate, true))
				{
					timeline[i]->Print(temp);
				}
			}
		}
	}

	void USERS::PrintForHome()
	{
		cout << Fname << " " << Lname;
	}

	void USERS::SetFriend(USERS* ptr)
	{
		if (numFriends == 0)
		{
			FriendList = new USERS * [10];
			for (int i = 0; i < 10; i++)
			{
				FriendList[i] = 0;
			}
		}
		FriendList[numFriends] = ptr;
		numFriends++;
	}

	void USERS::AddPostToTimeline(POST* ptr)
	{
		if (totalTimeline == 0)
		{
			timeline = new POST * [10];
			for (int i = 0; i < 10; i++)
			{
				timeline[i] = 0;
			}
			timeline[totalTimeline] = ptr;
			totalTimeline++;
		}
		else
		{
			timeline[totalTimeline] = ptr;
			totalTimeline++;
		}
	}

	void USERS::ViewFriendList()
	{
		if (FriendList != 0)
		{
			cout << "---------------------------------- Friend List ----------------------------------" << endl;
			for (int i = 0; i < numFriends; i++)
			{
				FriendList[i]->Print();
			}
		}
	}

	void USERS::ViewLikedPages()
	{
		if (LikedPages != 0)
		{
			cout << "---------------------------------- Liked Pages ----------------------------------" << endl;
			for (int i = 0; i < numPages; i++)
			{
				LikedPages[i]->Print();
			}
		}
	}

	void USERS::Print()
	{
		cout << this->GetId() << "\t" << Fname << " " << Lname << endl;
	}

	
	char* USERS::GetId()
	{
		return this->GetID();
	}
