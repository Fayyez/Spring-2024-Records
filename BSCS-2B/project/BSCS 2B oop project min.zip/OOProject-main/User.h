#pragma once
#ifndef USERS_H
#define USERS_H

#include<iostream>
using namespace std;
#include "Support.h"
#include "Post.h"
#include "Date.h"
#include"Object.h"
#include "Page.h"



class USERS : public OBJECT
{
    char* Fname;
    char* Lname;
    PAGES** LikedPages;
    USERS** FriendList;
    POST** timeline;
    int totalTimeline;
    int numPages;
    int numFriends;

public:
    USERS();
    ~USERS();
    void ReadDataFromFile(ifstream& inp);
    void SetPage(PAGES* ptr);
    void CheckDate(DATE CurrentDate, bool isMemory);
    void LikePost(POST* post);
    void HomePage(DATE currentDate);
    void ViewTimeline();
    void SeeMemory(DATE currentDate);
    void PrintForHome();
    void SetFriend(USERS* ptr);
    void AddPostToTimeline(POST* ptr);
    void ViewFriendList();
    void ViewLikedPages();
    void Print();
    char* GetId();
};

#endif 
