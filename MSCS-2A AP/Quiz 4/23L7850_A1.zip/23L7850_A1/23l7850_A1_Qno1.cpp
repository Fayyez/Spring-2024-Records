#include <iostream>
#include <limits> // for numeric_limits
#include <sstream> // for string stream

template<typename T>
class SortedSet {
private:
    struct Node {
        T data;
        Node* next;
        Node(const T& value) : data(value), next(nullptr) {}
    };

    Node* head;
    Node* tail;
    int size;

    void insertNode(const T& data) {
        Node* newNode = new Node(data);
        if (!head || data < head->data) {
            newNode->next = head;
            head = newNode;
            if (!tail) tail = head;
        } else if (data > tail->data) {
            tail->next = newNode;
            tail = newNode;
        } else {
            Node* temp = head;
            while (temp->next && temp->next->data < data) {
                temp = temp->next;
            }
            if (temp->next && temp->next->data == data) {
                delete newNode;
                return; 
            }
            newNode->next = temp->next;
            temp->next = newNode;
        }
        size++;
    }

public:
    SortedSet() : head(nullptr), tail(nullptr), size(0) {}

    void insert(const T& data) {
        insertNode(data);
    }

    void removeAt(int index) {
        if (index < 0 || index >= getSize()) {
            std::cout << "Invalid index.\n";
            return;
        }
        if (index == 0) {
            Node* temp = head;
            head = head->next;
            delete temp;
            if (!head) tail = nullptr;
        } else {
            Node* temp = head;
            for (int i = 0; i < index - 1; ++i) {
                temp = temp->next;
            }
            Node* toDelete = temp->next;
            temp->next = temp->next->next;
            delete toDelete;
            if (!temp->next) tail = temp;
        }
    }

    void print() const {
        Node* temp = head;
        while (temp) {
            std::cout << temp->data << " ";
            temp = temp->next;
        }
        std::cout << "\n";
    }

    int getSize() const {
        int count = 0;
        Node* temp = head;
        while (temp) {
            count++;
            temp = temp->next;
        }
        return count;
    }

    void rotate(int k) {
        if (k <= 0 || k >= getSize()) {
            std::cout << "Invalid value of k.\n";
            return;
        }
        Node* current = head;
        int count = 1;
        while (count < k && current != nullptr) {
            current = current->next;
            count++;
        }
        if (current == nullptr) return;

        Node* kthNode = current;
        while (current->next != nullptr) {
            current = current->next;
        }
        current->next = head;
        head = kthNode->next;
        kthNode->next = nullptr;
    }

    void reverseList() {
        Node* prev = nullptr;
        Node* current = head;
        Node* nextNode = nullptr;

        while (current != nullptr) {
            nextNode = current->next;
            current->next = prev;
            prev = current;
            current = nextNode;
        }
        head = prev;
    }

    void inputList() {
        T value;
        std::string input;
        while (true) {
            std::cin >> input;
            if (input == "s") break;
            std::istringstream stream(input);
            if (!(stream >> value)) {
                std::cout << "Invalid input. Please enter a valid value or 's' to stop.\n";
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                continue;
            }
            insert(value);
        }
    }

    void unionSet(const SortedSet<T>& otherSet) {
        Node* temp = otherSet.head;
        while (temp) {
            insertNode(temp->data);
            temp = temp->next;
        }
    }
};

int main() {
    SortedSet<int> a, b;
    int value, k;
    std::string val;

    std::cout << "Enter the values for set A: ";
    a.inputList();

    std::cout << "Enter the values for set B: ";
    b.inputList();

    std::cout << "Sorted set A: ";
    a.print();
    std::cout << "Sorted set B: ";
    b.print();

    a.unionSet(b);

    std::cout << "After union, set A:";
    a.print();

    std::cout << "Enter the value of k for rotation: ";
    std::cin >> k;
    while (k <= 0 || k >= a.getSize()) {
        std::cout << "Invalid value of k. Please enter again: ";
        std::cin >> k;
    }

    std::cout << "Original linked list: ";
    a.print();

    a.rotate(k);

    std::cout << "Linked list after rotating by " << k << " nodes: ";
    a.print();
    
	a.reverseList();

    std::cout << "Reversed linked list: ";
    a.print();

    return 0;
}
